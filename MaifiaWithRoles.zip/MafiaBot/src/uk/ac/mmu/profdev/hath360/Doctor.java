package uk.ac.mmu.profdev.hath360;

import net.dv8tion.jda.api.entities.Member;

public class Doctor extends Villager {

	private Player healedMember;
	
	public Doctor(Member player) {
		super(player);
		// TODO Auto-generated constructor stub
	}

	public Player getHealedMember() {
		return healedMember;
	}

	public void setHealedMember(Player healedMember) {
		this.healedMember = healedMember;
	}

	
}
