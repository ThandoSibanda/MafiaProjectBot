package uk.ac.mmu.profdev.hath360;

import javax.security.auth.login.LoginException;

import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;

public class StartUp {
	public static void main(String[] args) throws LoginException{
		JDABuilder jda = JDABuilder.createDefault("");
		jda.setActivity(Activity.playing("Mafia"));
		jda.setStatus(OnlineStatus.ONLINE);
		jda.addEventListeners(new Commands());
		jda.build();
	}
}
