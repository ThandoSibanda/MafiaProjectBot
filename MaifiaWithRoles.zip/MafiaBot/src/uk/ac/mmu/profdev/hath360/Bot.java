package uk.ac.mmu.profdev.hath360;

import javax.security.auth.login.LoginException;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;



public class Bot {

	JDA jda;
	
	public static void main(String[] args) {
		
		
		
	}
	
	
	public void intialize() {
		try {
			jda = JDABuilder.createDefault("OTI1NTIxNDYyMTI1NzkzMzAx.YcuVBw.-WN4qqhEkLGE1Bfri0BM0hnYEDk").build();
		} catch (LoginException e) {
			
			e.printStackTrace();
		}
	}

}
