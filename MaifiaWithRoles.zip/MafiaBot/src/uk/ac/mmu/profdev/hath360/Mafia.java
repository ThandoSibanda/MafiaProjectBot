package uk.ac.mmu.profdev.hath360;

import net.dv8tion.jda.api.entities.Member;

public class Mafia extends Player{
	
	private int amountOfMafia = 0;
	private boolean Discoverable;
	private Player voteToKill; 

	public Mafia(Member players) {
		super(players);
		amountOfMafia = getAmountOfMafia() + 1;
	}

	public int getAmountOfMafia() {
		return amountOfMafia;
	}

	public boolean isDiscoverable() {
		return Discoverable;
	}

	
}
