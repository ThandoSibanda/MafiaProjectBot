package uk.ac.mmu.profdev.hath360;

import net.dv8tion.jda.api.entities.Member;

public class Cop extends Villager{

	private Player investigate;
	
	public Cop(Member player) {
		super(player);
	}

	public Player getInvestigate() {
		return investigate;
	}

	public void setInvestigate(Player search) {
		this.investigate = search;
	}
	
	

}
