package uk.ac.mmu.profdev.hath360;

public class Timer {

}
