package uk.ac.mmu.profdev.hath360;

import net.dv8tion.jda.api.entities.Member;

public class Villager extends Player {

	
	public Villager(Member player) {
		super(player);
	}
	
	

}
