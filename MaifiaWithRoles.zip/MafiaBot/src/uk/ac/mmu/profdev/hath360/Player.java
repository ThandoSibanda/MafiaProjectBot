package uk.ac.mmu.profdev.hath360;

import net.dv8tion.jda.api.entities.Member;

public abstract class Player {

	private String name;
	private Member guildMember;
	private int votesFor;
	private Player villageVote;
	private boolean saved;
	private boolean alive;
	
	public Player(Member player) {
		this.guildMember = player;
		this.name = player.getNickname();
		this.votesFor = 0;
		this.villageVote = null;
		this.saved = false;
		this.alive = true;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Member getGuildMember() {
		return guildMember;
	}

	public Player getVillageVote() {
		return villageVote;
	}

	public void setVillageVote(Player villageVote) {
		this.villageVote = villageVote;
	}

	public int getVotesFor() {
		return votesFor;
	}

	public void setVotesFor(int votesFor) {
		this.votesFor = votesFor;
	}

	public boolean isSaved() {
		return saved;
	}

	public void setSaved(boolean saved) {
		this.saved = saved;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}
}
